#pragma once

void getWords();